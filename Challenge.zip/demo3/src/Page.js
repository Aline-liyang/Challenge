import { Component } from "react";
import * as React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Typography from "@material-ui/core/Typography";
import Slider from "@material-ui/core/Slider";
import { Button } from "@material-ui/core";

class Page extends Component {
  state = {
    kilo: "0 K PAGEVIEWS",
    money: 18.0,
    billing: "Monthly Billing",
  };

  startTrial = () => {
    console(this.state);
  };

  changerKilo = (e) => {
    this.setState({ kilo: e.target.value });
  };

  changerMoney = () => {
    if (this.state.kilo === "10" && this.state.billing === "Monthly Billing") {
      this.setState({ money: 6.0 });
    } else if (
      this.state.kilo === "10" &&
      this.state.billing === "Yearly Billing"
    ) {
      this.setState({ money: 6.0 * 0.75 });
    } else if (
      this.state.kilo === "50" &&
      this.state.billing === "Monthly Billing"
    ) {
      this.setState({ money: 12.0 });
    } else if (
      this.state.kilo === "50" &&
      this.state.billing === "Yearly Billing"
    ) {
      this.setState({ money: 12.0 * 0.75 });
    } else if (
      this.state.kilo === "100" &&
      this.state.billing === "Monthly Billing"
    ) {
      this.setState({ money: 16.0 });
    } else if (
      this.state.kilo === "100" &&
      this.state.billing === "Yearly Billing"
    ) {
      this.setState({ money: 16.0 * 0.75 });
    } else if (
      this.state.kilo === "500" &&
      this.state.billing === "Monthly Billing"
    ) {
      this.setState({ money: 24.0 });
    } else if (
      this.state.kilo === "500" &&
      this.state.billing === "Yearly Billing"
    ) {
      this.setState({ money: 24.0 * 0.75 });
    } else if (
      this.state.kilo === "1000" &&
      this.state.billing === "Monthly Billing"
    ) {
      this.setState({ money: 36.0 });
    } else if (
      this.state.kilo === "1000" &&
      this.state.billing === "Yearly Billing"
    ) {
      this.setState({ money: 36.0 * 0.75 });
    } else {
      this.setState({ money: 0 });
    }
  };

  onBillingChange = (e) => {
    this.setState({ billing: e.target.value });
  };

  render() {
    console.log(this.state);
    const optionsBilling = [
      { value: "Monthly Billing", key: "1", text: "Monthly Billing" },
      { value: "Yearly Billing", key: "2", text: "Yearly Billing" },
    ];

    return (
      <div id="main">
        <div id="title">
          <h1 className="mainh1">Simple, traffic-based pricing</h1>
          <p className="mainp">
            Sign-up for our 30-day trial. No credit card required.
          </p>
        </div>
        <div id="page">
          <div className="top">
            <div className="headpage">
              <span className="kiloStyle">{this.state.kilo}K PAGEVIEWS</span>
              <span className="moneyStyle">
                <span className="moneyBold">$ {this.state.money}</span> /month
              </span>
            </div>
            <br />

            <div className="sliderPart">
              <p>
                {" "}
                Kilo:{" "}
                <input
                  type="text"
                  placeholder="Enter the kilo"
                  onChange={this.changerKilo}
                />
              </p>
            </div>
            <div className="togglePart">
              <p>
                <select
                  className="selectOption"
                  name="billingmode"
                  id="billing"
                  onChange={this.onBillingChange}
                >
                  <option value="Monthly Billing">Monthly Billing</option>
                  <option value="Yearly Billing">Yearly Billing</option>
                </select>{" "}
                <span> </span>
                <button className="confirm" onClick={this.changerMoney}>
                  {" "}
                  Confirm{" "}
                </button>{" "}
              </p>
              <button id="discount">Yearly Billing: 25% discount</button>
            </div>
          </div>
          <div className="Button">
            <div className="feetleft">
              <ul>
                <li> Unlimited websites</li>
                <li> 100% data ownership</li>
                <li> Email reports </li>
              </ul>
            </div>

            <div className="feetright">
              <button className="buttontrail" onClick={this.startTrial}>
                Start my trial
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Page;
