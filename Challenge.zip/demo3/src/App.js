import { Component } from "react";

import "./App.css";
import Page from "./Page";

class App extends Component {
  render() {
    return (
      <div>
        <Page />
      </div>
    );
  }
}
export default App;
