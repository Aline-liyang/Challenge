import { Component } from "react";

import { Button, Select } from "semantic-ui-react";

class Page extends Component {
  state = {
    kilo: "100",
    money: "$16.00",
    billing: "Monthly Billing",
  };

  startTrial = () => {
    console(this.state);
  };

  render() {
    console.log(this.state);

    return (
      <div id="main">
        <div id="title">
          <h1 className="mainh1">Simple, traffic-based pricing</h1>
          <p className="mainp">
            Sign-up for our 30-day trial. No credit card required.
          </p>
        </div>
        <div id="page">
          <div className="top">
            <div className="headpage">
              <span className="kiloStyle">{this.state.kilo}K PAGEVIEWS</span>
              <span className="moneyStyle">
                <span className="moneyBold">{this.state.money}</span> /month
              </span>
            </div>
            <br />
            <br />
            <div className="sliderPart">
              <input
                className="slider"
                id="kilovalue"
                name="kilovalue"
                type="range"
                min="10"
                max="1000"
                value="100"
              />

              <br />
            </div>

            <div className="togglePart">
              <p>
                {" "}
                Monthly Billing{" "}
                <input type="checkbox" id="switch" class="checkbox" />
                <label for="switch" class="toggle" />
                <span> Yearly Billing</span>{" "}
                <button id="discount">25% discount</button>
              </p>
              <br />
            </div>
          </div>
          <div className="Button">
            <div className="feetleft">
              <ul>
                <li> Unlimited websites</li>
                <li> 100% data ownership</li>
                <li> Email reports </li>
              </ul>
            </div>

            <div className="feetright">
              <button className="buttontrail" onClick={this.startTrial}>
                Start my trial
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Page;
